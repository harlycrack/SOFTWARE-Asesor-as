<!DOCTYPE html>
<!-- Coding by CodingNepal || www.codingnepalweb.com -->
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
	
    <!-- Boxicons CSS -->
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet" />
    <title>Menú Alumno</title>
    <link rel="stylesheet" href="styleMenu.css" />
  </head>
  <body>
  
 <!-- navbar -->
<nav class="navbar">
    <div class="logo_item">
        <i class="bx bx-menu" id="sidebarOpen"></i>
        <img src="img/logo.png" alt="">EducaTec
    </div>
  <ul>
    <li class="menu-desplegable">
      <a href="#">
        <img src="img/usuarioDos.png" alt="Menú">
      </a>
      <ul class="submenu">
        <li><a href="#">Informacion Alumno</a></li>
        <li><a href="#">Cerrar Sesión</a></li>
      </ul>
    </li>
  </ul>
</nav>

<!-- sidebar -->
<nav class="sidebar">
    <div class="menu_content">
        <ul class="menu_items">
            <li class="item">
                <br></br>

                <a href="menualumno.php" class="nav_link submenu_item">
                <img src="img/hogar-dos.png" alt="logo" class="profile" id="profileIcon"/>
                <span class="navlink">Inicio</span>
                </a>
            </li>
            <li class="item">
                <a href="ver_materia.php" class="nav_link submenu_item">
                <img src="img/materia.png" alt="logo" class="profile" id="profileIcon"/>
                    <span class="navlink">En curso</span>
                </a>
            </li>
            <li class="item">
                <a href="seleccionar_materia.php" class="nav_link submenu_item">
                <img src="img/seleccione.png" alt="logo" class="profile" id="profileIcon"/>
                    <span class="navlink">Seleccionar Materias</span>
                </a>
            </li>
            <li class="item">
                <a href="CambiarContrasena.php" class="nav_link">
                <img src="img/cambiar-contra.png" alt="logo" class="profile" id="profileIcon"/>
                    <span class="navlink">Cambiar Contraseña</span>
                </a>
            </li>
            <li class="item">
                <a href="loginalumno.php" class="nav_link">
                <img src="img/cerrar-sesion.png" alt="logo" class="profile" id="profileIcon"/>
                    <span class="navlink">Cerrar Sesión</span>
                </a>
            </li>
        </ul>
    </nav>

<!-- JavaScript -->
<script src="js/script.js"></script>

<!-- Imagen de usuario -->
<style>
nav {
  position: relative; 
}

.menu-desplegable {
  position: relative; 
}

.submenu {
  display: none; 
  position: absolute; 
  top: 100%;
  left: 0;
  background-color: #fff; 
  padding: 10px;
  z-index: 1;
}

.menu-desplegable:hover .submenu {
  display: block; 
}
</style>

<!-- Bienvenida -->
<style>
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
        background-color: #9ad4fb;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
    }

    .welcome-text {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        text-align: center;
        font-size: 24px;
        font-weight: bold;
    }
</style>
<body>

 <!-- CAMBIAR CONTRASEÑA --> 
    <style>
        body {
            background-color: #9ad4fb; 
            display: flex;
            justify-content: center; 
            align-items: center; 
            height: 100vh;
            margin: 0; 
        }

        .error {color:RED;}
        form {width:400px; font-family:Arial; padding: 20px; background-color: white ; 
		border-radius: 10px; box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);}
        form input {font-family:Arial; padding: 8px; margin-bottom: 10px; width: 100%; box-sizing: border-box; border: 1px solid #ccc; border-radius: 4px;}
        form>div {margin:5px;}
        form>div:last-child {text-align:center;margin-top:10px;}
    </style>
 
    <script>
    /**
     * Function que inserta un error por encima del elemento recibido
     * @param element -> texto que haga referencia al elemento
     * @param error -> texto del error
     */
    const showError = (element, error) => {
        const errorEl=document.createElement("div");
        errorEl.setAttribute("class","error");
        errorEl.innerHTML=error;
        document.querySelector(element).parentElement.prepend(errorEl);
    }
 
    const validatePassword = () => {
        //Cogemos los valores actuales del formulario
        const pasActual=document.formName.passwordActual.value;
        const pasNew1=document.formName.passwordNew1.value;
        const pasNew2=document.formName.passwordNew2.value;
 
        //Patron para los numeros
        const patron1=new RegExp("[0-9]+");
        //Patron para las letras
        const patron2=new RegExp("[a-zA-Z]+");
 
        // Eliminamos los posible errores
        for (let el of document.querySelectorAll("div[class=error]")) {
            el.remove();
        }
 
        if (pasNew1!=pasNew2 || pasNew1.length<6 || pasActual=="" || pasNew1.search(patron1)<0 || pasNew1.search(patron2)<0) {
            if (pasActual=="") {
                showError("input[name=passwordActual]", "Indicar tu contraseña actual");
            }
            if (pasNew1.length<6) {
                showError("input[name=passwordNew1]", "La longitud mínima tiene que ser de 6 caracteres");
            } else if (pasNew1!=pasNew2) {
                showError("input[name=passwordNew1]", "La copia de la nueva contraseña no coincide");
            } else if (pasNew1.search(patron1)<0 || pasNew1.search(patron2)<0) {
                showError("input[name=passwordNew1]", "La contraseña tiene que tener numeros y letras");
            }
            return false;
        }
        return true;
    }
    </script>
</head>
 
<body>

<form name="formActualizaContrasena" action="ActualizaContrasena.php" method="POST">
    <div><strong>Nueva Contraseña:</strong><input type="password" name="newPassword"></div>
    <div><strong>Repite Contraseña:</strong><input type="password" name="repeatNewPassword"></div>
    <div><input type="submit" value="Actualizar Contraseña"></div>
</form>
 
</body>
</html>