<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menú Alumno </title>
    <link rel="stylesheet" href="styleMenu.css">

    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
</head>
<body>

<!-- navbar -->
<nav class="navbar">
    <div class="logo_item">
        <i class="bx bx-menu" id="sidebarOpen"></i>
        <img src="img/logo.png" alt="">EducaTec
    </div>
  <ul>
    <li class="menu-desplegable">
      <a href="#">
        <img src="img/usuarioDos.png" alt="Menú">
      </a>
      <ul class="submenu">
        <li><a href="#">Informacion Alumno</a></li>
        <li><a href="#">Cerrar Sesión</a></li>
      </ul>
    </li>
  </ul>
</nav>

<!-- sidebar -->
<nav class="sidebar">
    <div class="menu_content">
        <ul class="menu_items">
            <li class="item">
                <br></br>

                <a href="menuAlumno.php" class="nav_link submenu_item">
                <img src="img/hogar-dos.png" alt="logo" class="profile" id="profileIcon"/>
                <span class="navlink">Inicio</span>
                </a>
            </li>
            <li class="item">
                <a href="en_curso.php" class="nav_link submenu_item">
                <img src="img/materia.png" alt="logo" class="profile" id="profileIcon"/>
                    <span class="navlink">En curso</span>
                </a>
            </li>
            <li class="item">
                <a href="seleccionar_materia.php" class="nav_link submenu_item">
                <img src="img/seleccione.png" alt="logo" class="profile" id="profileIcon"/>
                    <span class="navlink">Seleccionar Materias</span>
                </a>
            </li>
            <li class="item">
                <a href="cambiar_contraseña.php" class="nav_link">
                <img src="img/cambiar-contra.png" alt="logo" class="profile" id="profileIcon"/>
                    <span class="navlink">Cambiar Contraseña</span>
                </a>
            </li>
            <li class="item">
                <a href="loginDocente.php" class="nav_link">
                <img src="img/cerrar-sesion.png" alt="logo" class="profile" id="profileIcon"/>
                    <span class="navlink">Cerrar Sesión</span>
                </a>
            </li>
        </ul>
    </nav>

<!-- JavaScript -->
<script src="js/script.js"></script>

<!-- Imagen de usuario -->
<style>
nav {
  position: relative; 
}

.menu-desplegable {
  position: relative; 
}

.submenu {
  display: none; 
  position: absolute; 
  top: 100%;
  left: 0;
  background-color: #fff; 
  padding: 10px;
  z-index: 1;
}

.menu-desplegable:hover .submenu {
  display: block; 
}
</style>

<!-- Bienvenida -->
<style>
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
        background-color: #9ad4fb;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
    }

    .welcome-text {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        text-align: center;
        font-size: 24px;
        font-weight: bold;
    }
</style>
<div class="welcome-text"></div>

<style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #9ad4fb;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 50vh;
        }

        .table-container {
            text-align: left;
        }

        table {
            width: 200%;
            border-collapse: collapse;
            margin: auto; 
        }

        table, th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>

<div class="table-container">
    <h2>Materias</h2>
    <table>
        <tr>
            <th>Nombre</th>
            <th>Hora</th>
            <th>Día</th>
            <th>Aula</th>
        </tr>
    </TABLE>

</body>
</div>

<!-- JavaScript -->
<script src="https://unpkg.com/jquery@3.6.0/dist/jquery.min.js"></script>
<script src="https://unpkg.com/moment@2.29.4/moment.min.js"></script>
<script src="https://unpkg.com/fullcalendar@5.11.2/main.min.js"></script>
<script src="https://unpkg.com/fullcalendar@5.11.2/main.min.js"></script>
</body>
</html>