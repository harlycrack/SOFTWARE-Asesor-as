consultarDatos();

function insertar() {
    var datos = new FormData();

    datos.append('nombre', $("#txtNombre").val());
    datos.append('precio', $('#txtPrecio').val());
    datos.append('accion', 'insertar');
    /* 
   for (var value of datos.values()) {
        console.log(value); 
     }
*/
    $.ajax({
        type: "post",
        url: "index_back.php",
        processData: false,
        contentType: false,
        data: datos,
        success: function (response) {
            consultarDatos();
            limpiarCampos();
        }, error: function (XMLHttpRequest, textStatus, errorThrown) {
            alert("Status: " + textStatus); alert("Error: " + errorThrown);
        }
    });
}

function consultarDatos() {
    $("#registros").empty();
    $.getJSON("index_back.php", function (registros) {
        var items = [];
        $.each(registros, function (key, val) {
            if (key > 0) {
                var template = "<tr>"
                template += "<td>" + val.id + "</td>";
                template += "<td>" + val.nombre + "</td>";
                template += "<td>" + val.precio + "</td>";
                template += '<td><input class="btn btn-info" type="button" onclick="javascript:seleccionar(' + val.id + ')"  value="Seleccionar"/>';
                template += '<input class="btn btn-danger" type="button" onclick="javascript:borrar(' + val.id + ')" value="Borrar"/></td>';
                template += "</tr>";
                items.push(template);
            }

        });
        $("#registros").append(items.join(""));
    });
}


function seleccionar(id) {
    $.getJSON("index_back.php?consultar=" + id, function (registros) {
        
        $("#txtID").val(registros.id);
        $("#txtNombre").val(registros.nombre);
        $("#txtPrecio").val(registros.precio);

        $("#btnAgregar").addClass('disabled');
        $("#btnEditar").removeClass('disabled');
        $("#btnCancelar").removeClass('disabled');
    });

}
function editar() {
    var datos = new FormData();
    datos.append('id', $("#txtID").val());
    datos.append('nombre', $("#txtNombre").val());
    datos.append('precio', $('#txtPrecio').val());
    $.ajax({
        type: "post",
        url: "index_back.php?actualizar=1",
        processData: false,
        contentType: false,
        data: datos,
        success: function (response) {
            consultarDatos();
            limpiarCampos();

        }
    });

}

function limpiarCampos() {

    $("#txtID").val("");
    $("#txtNombre").val("");
    $("#txtPrecio").val("");

    $("#btnAgregar").removeClass('disabled');
    $("#btnEditar").addClass('disabled');
    $("#btnCancelar").addClass('disabled');

}

function borrar(id) {
    $.get("index_back.php?borrar=" + id, function () {
        consultarDatos();

    });
}


$(document).ready( function () {
    $('#datatable-crud').DataTable();
} );


