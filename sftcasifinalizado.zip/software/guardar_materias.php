<?php
// Verifica si se ha enviado el formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Verifica si se han seleccionado materias
    if (isset($_POST['materias']) && !empty($_POST['materias'])) {
        // Abre el archivo para escritura (creará uno nuevo si no existe)
        $archivo = fopen("materiasCurso.html", "w");

        // Verifica si se pudo abrir el archivo
        if ($archivo) {
            // Escribe el encabezado del HTML
            fwrite($archivo, "<!DOCTYPE html>\n");
            fwrite($archivo, "<html lang=\"es\">\n");
            fwrite($archivo, "<head>\n");
            fwrite($archivo, "    <meta charset=\"UTF-8\">\n");
            fwrite($archivo, "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n");
            fwrite($archivo, "    <title>Materias del Curso</title>\n");
            fwrite($archivo, "</head>\n");
            fwrite($archivo, "<body>\n");
            fwrite($archivo, "    <h1>Materias del Curso</h1>\n");
            fwrite($archivo, "    <ul>\n");

            // Recorre las materias seleccionadas y las escribe en el archivo HTML
            foreach ($_POST['materias'] as $materia) {
                fwrite($archivo, "        <li>$materia</li>\n");
            }

            // Escribe el cierre del HTML
            fwrite($archivo, "    </ul>\n");
            fwrite($archivo, "</body>\n");
            fwrite($archivo, "</html>\n");

            // Cierra el archivo
            fclose($archivo);

            echo "Materias guardadas correctamente en el archivo materiasCurso.html.";
        } else {
            echo "Error al abrir el archivo para escribir las materias.";
        }
    } else {
        echo "Por favor, selecciona al menos una materia.";
    }
}
?>
