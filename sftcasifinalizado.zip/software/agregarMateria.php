
<?php
// Conexión a la base de datos
include("conexion.php");

// Verificar la conexión
if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

// Obtener los datos del formulario
$materia = $_POST['Nombre'];
$horaClase = $_POST['Hora'];
$horario = $_POST['Dia'];
$aula = $_POST['Aula'];

// Consulta SQL para insertar los datos en la tabla
$sql = "INSERT INTO materias (Nombre, Dia, Aula, Hora) 
        VALUES ('$materia', '$horario', '$aula', '$horaClase')";

if ($conexion->query($sql) === TRUE) {
  echo "Materia agregada correctamente";
} else {
  echo "Error al agregar materia: " . $conexion->error;
}

// Cerrar la conexión
$conexion->close();
?>

