<!DOCTYPE html>
<!-- Verificar si el usuario ha iniciado sesión
if(isset($_SESSION['user'])) {
    $usuarioID = $_SESSION['user'];
    // Ahora puedes utilizar $usuarioID para realizar consultas o mostrar información específica del usuario en esta página.
} else {
    // Si el usuario no ha iniciado sesión, redirigirlo a la página de inicio de sesión u otra página apropiada.
    header("location: iniciar_sesion.php");
    exit();
} -->

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menú Docente </title>
    <link rel="stylesheet" href="styleMenu.css">

    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
</head>
<body>

<!-- navbar -->
<nav class="navbar">
    <div class="logo_item">
        <i class="bx bx-menu" id="sidebarOpen"></i>
        <img src="img/logo.png" alt="">EducaTec
    </div>
  <ul>
    <li class="menu-desplegable">
      <a href="#">
        <img src="img/usuarioDos.png" alt="Menú">
      </a>
      <ul class="submenu">
        <li><a href="#">Informacion Alumno</a></li>
        <li><a href="#">Cerrar Sesión</a></li>
      </ul>
    </li>
  </ul>
</nav>

<!-- sidebar -->
<nav class="sidebar">
    <div class="menu_content">
        <ul class="menu_items">
            <li class="item">
                <br></br>

                <a href="menudocente.php" class="nav_link submenu_item">
                <img src="img/hogar-dos.png" alt="logo" class="profile" id="profileIcon"/>
                <span class="navlink">Inicio</span>
                </a>
            </li>
            <li class="item">
                <a href="mat.php" class="nav_link submenu_item">
                <img src="img/registro.png" alt="logo" class="profile" id="profileIcon"/>
                    <span class="navlink">Registrar Materia</span>
                </a>
            </li>
            <li class="item">
                <a href="cambiar_contraeña.php" class="nav_link">
                <img src="img/cambiar-contra.png" alt="logo" class="profile" id="profileIcon"/>
                    <span class="navlink">Cambiar Contraseña</span>
                </a>
            </li>
            <li class="item">
                <a href="loginDocente.php" class="nav_link">
                <img src="img/cerrar-sesion.png" alt="logo" class="profile" id="profileIcon"/>
                    <span class="navlink">Cerrar Sesión</span>
                </a>
            </li>
        </ul>
        <!-- Sidebar Open / Close -->
        
</nav>

<!-- JavaScript -->
<script src="js/script.js"></script>

<!-- Imagen de usuario -->
<style>
nav {
  position: relative; 
}

.menu-desplegable {
  position: relative; 
}

.submenu {
  display: none; 
  position: absolute; 
  top: 100%;
  left: 0;
  background-color: #fff; 
  padding: 10px;
  z-index: 1;
}

.menu-desplegable:hover .submenu {
  display: block; 
}
</style>

<!-- Bienvenida -->
<style>
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
        background-color: #9ad4fb;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
    }

    .welcome-text {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        text-align: center;
        font-size: 24px;
        font-weight: bold;
    }
</style>
<body>
  
    <!-- Bienvenida -->
    <div class="welcome-text">Bienvenido Docente</div>
	
  </body>



<!-- JavaScript -->
<script src="https://unpkg.com/jquery@3.6.0/dist/jquery.min.js"></script>
<script src="https://unpkg.com/moment@2.29.4/moment.min.js"></script>
<script src="https://unpkg.com/fullcalendar@5.11.2/main.min.js"></script>
<script src="https://unpkg.com/fullcalendar@5.11.2/main.min.js"></script>
</body>
</html>
