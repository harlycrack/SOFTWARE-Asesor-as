<?php
// Datos de conexión a la base de datos
$server = "localhost"; // Host de la base de datos (usualmente localhost)
$username = "root"; // Nombre de usuario de la base de datos 
$password = ""; // Contraseña de la base de datos 
$database = "asesorias"; // Nombre de la base de datos a la que te quieres conectar

// Crear conexión
$conexion = new mysqli($server, $username, $password, $database);

// Revisar si hay errores de conexión
if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}
?>

