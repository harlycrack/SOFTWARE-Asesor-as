<?php
session_start();

$error_message = ""; // Inicializamos la variable de mensaje de error

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $usuario = $_POST['username'];
    $contrasena = $_POST['password'];
    
    include("conexion.php");
    
    $consulta = "SELECT * FROM alumnos WHERE Id ='$usuario' and contraseña='$contrasena'";
    $resultado = mysqli_query($conexion, $consulta);
    $filas = mysqli_num_rows($resultado);

    if ($filas) {
        $row = mysqli_fetch_assoc($resultado);
        $_SESSION['alumno_Id'] = $row['alumno_Id']; // Asegúrate de que este es el campo correcto para el ID del alumno
        header("location: menuAlumno.php");
        exit();
    } else {
        $consulta_usuario = "SELECT * FROM alumnos WHERE Id ='$usuario'";
        $resultado_usuario = mysqli_query($conexion, $consulta_usuario);
        $filas_usuario = mysqli_num_rows($resultado_usuario);
        include("login2.php");
        if ($filas_usuario) {
            // La contraseña es incorrecta
            ?>
            <div id="error-message" style="background-color: #ffcccc; color: #cc0000; padding: 20px; border: 2px solid #cc0000; border-radius: 10px; text-align: center; position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);">
                <p style="font-size: 18px; margin: 0;"><?php echo $error_message?></p>
                <p style="font-size: 16px; margin: 0;">Contraseña incorrecta. Por favor inténtalo de nuevo.</p>
            </div>
            <?php
        } else {
            // El usuario no está registrado
            ?>
            <div id="error-message" style="background-color: #ffcccc; color: #cc0000; padding: 20px; border: 2px solid #cc0000; border-radius: 10px; text-align: center; position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);">
                <p style="font-size: 18px; margin: 0;">Usuario no registrado. Por favor inténtalo de nuevo.</p>
            </div>
            <?php
        }
        
        // Ocultar el mensaje de error después de 5 segundos
        ?>
        <script>
            setTimeout(function() {
                var errorMessage = document.getElementById('error-message');
                errorMessage.style.display = 'none';
            }, 5000); // 5000 milisegundos = 5 segundos
        </script>
        <?php
    }
    
    mysqli_free_result($resultado);
    mysqli_close($conexion);
}
?>
