<?php
session_start();

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['alumno_Id'])) {
    header("Location: loginAlumno.php");
    exit();
}

// Conexión a la base de datos
include("conexion.php");

// Consulta SQL para obtener las materias
$sql = "SELECT * FROM materias";
$result = $conexion->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "Materia: " . $row['Nombre'] . "<br>";
        echo "Día: " . $row['Dia'] . "<br>";
        echo "Hora: " . $row['Hora'] . "<br>";
        echo "Aula: " . $row['Aula'] . "<br>";
        echo "<a href='inscribirse.php?materia_id=" . $row['materia_Id'] . "'>Inscribirse</a><br><br>";
    }
} else {
    echo "No hay materias disponibles.";
}

// Cerrar la conexión
$conexion->close();
?>

