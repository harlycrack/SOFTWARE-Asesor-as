<?php
session_start();
if (!isset($_SESSION['username'])) {
    // Redirigir si el usuario no está autenticado
    header("Location: login2.php");
    exit();
}

include("conexion.php");

$usuario = $_SESSION['username'];
$newPassword = $_POST['newPassword'];
$repeatNewPassword = $_POST['repeatNewPassword'];
$error = "";

// Verificar si los campos están vacíos
if (empty($newPassword) && empty($repeatNewPassword)) {
    include("CambiarContrasena.php");
    // Mostrar un mensaje de error si ambos campos están vacíos
    ?>
    <div id="error" style="background-color: #ffcccc; color: #cc0000; padding: 20px; border: 2px solid #cc0000; border-radius: 10px; text-align: center; position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);">
        <p style="font-size: 18px; margin: 0;"><?php echo $error?></p>
        <p style="font-size: 16px; margin: 0;">Por favor, completa ambos campos de contraseña.</p>
    </div>
    <?php
    echo "<script>setTimeout(function() { document.getElementById('error').style.display = 'none'; }, 2000);</script>";
    exit();
}

// Verificar si alguno de los campos está vacío
if (empty($newPassword) || empty($repeatNewPassword)) {
    include("CambiarContrasena.php");
    // Mostrar un mensaje de error indicando qué campo está vacío
    if (empty($newPassword)) {
        ?>
        <div id="error" style="background-color: #ffcccc; color: #cc0000; padding: 20px; border: 2px solid #cc0000; border-radius: 10px; text-align: center; position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);">
            <p style="font-size: 18px; margin: 0;"><?php echo $error?></p>
            <p style="font-size: 16px; margin: 0;">Favor de llenar el campo de "Nueva Contraseña"</p>
        </div>
        <?php
    }
    if (empty($repeatNewPassword)) {
        ?>
        <div id="error" style="background-color: #ffcccc; color: #cc0000; padding: 20px; border: 2px solid #cc0000; border-radius: 10px; text-align: center; position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);">
            <p style="font-size: 18px; margin: 0;"><?php echo $error?></p>
            <p style="font-size: 16px; margin: 0;">Favor de llenar el campo de "Repite Contraseña"</p>
        </div>
        <?php
    }
    echo "<script>setTimeout(function() { document.getElementById('error').style.display = 'none'; }, 2000);</script>";
    exit();
}

// Verificar si las contraseñas coinciden
if ($newPassword !== $repeatNewPassword) {
    include("CambiarContrasena.php");
    // Las contraseñas no coinciden, mostrar un mensaje de error
    ?>
    <div id="error" style="background-color: #ffcccc; color: #cc0000; padding: 20px; border: 2px solid #cc0000; border-radius: 10px; text-align: center; position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);">
        <p style="font-size: 18px; margin: 0;"><?php echo $error?></p>
        <p style="font-size: 16px; margin: 0;">Las Contraseñas no coinciden</p>
    </div>
    <?php
    echo "<script>setTimeout(function() { document.getElementById('error').style.display = 'none'; }, 2000);</script>";
    exit();
}

// Actualizar la contraseña en la base de datos 
$consulta = "UPDATE alumnos SET contraseña = '$newPassword' WHERE Id = '$usuario'";
$resultado = mysqli_query($conexion, $consulta);

if ($resultado) {
    // Contraseña actualizada con éxito, mostrar un mensaje de éxito
    include("menuAlumno.php");
    ?>
    <div id="error" style="background-color: #ffcccc; color: #cc0000; padding: 20px; border: 2px solid #cc0000; border-radius: 10px; text-align: center; position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);">
        <p style="font-size: 18px; margin: 0;"><?php echo $error?></p>
        <p style="font-size: 16px; margin: 0;">Contraseña actualizada exitosamente</p>
    </div>
    <?php
} else {
    // Error al actualizar la contraseña, mostrar un mensaje de error
    ?>
    <div id="error" style="background-color: #ffcccc; color: #cc0000; padding: 20px; border: 2px solid #cc0000; border-radius: 10px; text-align: center; position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);">
        <p style="font-size: 18px; margin: 0;"><?php echo $error?></p>
        <p style="font-size: 16px; margin: 0;">Error al actualizar la contraseña</p>
    </div>
    <?php
}

mysqli_close($conexion);
?>

<!-- Agregar script de JavaScript al final de la página -->
<script>
    setTimeout(function() {
        document.getElementById('error').style.display = 'none';
    }, 2000);
</script>
