<?php
session_start();

// Conexión a la base de datos
include("conexion.php");

// Verificar la conexión
if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

// Obtener las materias disponibles
$sql = "SELECT materias.materia_id, materias.Nombre, materias.Maestro, materias.Dia, materias.Aula, materias.Limite_Inscripcion, materias.Hora 
        FROM materias";
$result = $conexion->query($sql);

// Obtener el ID del alumno desde la variable de sesión
$alumno_Id = $_SESSION['user'] ?? null;

if (!$alumno_Id) {
    die("Error: No se encontró el ID del alumno en la sesión.");
}

$message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['materia_id'])) {
    $materia_id = $_POST['materia_id'];

    // Verificar si el alumno_Id existe en la tabla 'alumnos'
    $result_check = $conexion->query("SELECT * FROM alumnos WHERE alumno_Id = '$alumno_Id'");
    
    if ($result_check->num_rows > 0) {
        // Insertar la inscripción en la base de datos
        $sql_inscripcion = "INSERT INTO inscripciones (alumno_Id, materia_id) VALUES ('$alumno_Id', '$materia_id')";
        
        if ($conexion->query($sql_inscripcion) === TRUE) {
            $message = "Inscripción exitosa.";
        } else {
            $message = "Error al inscribirse en la materia: " . $conexion->error;
        }
    } else {
        $message = "Error: el alumno_Id no existe en la tabla 'alumnos'.";
    }
}

// Obtener las inscripciones
$inscripciones = [];
$sql_inscripciones = "SELECT inscripciones.alumno_Id, alumnos.Nombre AS AlumnoNombre, inscripciones.materia_id 
                      FROM inscripciones 
                      JOIN alumnos ON inscripciones.alumno_Id = alumnos.alumno_Id";
$result_inscripciones = $conexion->query($sql_inscripciones);

if ($result_inscripciones->num_rows > 0) {
    while ($row = $result_inscripciones->fetch_assoc()) {
        $inscripciones[$row['materia_id']][] = $row['AlumnoNombre'];
    }
}

// Cerrar la conexión
$conexion->close();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Seleccionar Materia</title>
    <link rel="stylesheet" href="styleMenu.css">
    <style>
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid black;
        }
        th, td {
            padding: 15px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        .navbar {
            display: flex;
            justify-content: space-between;
            background-color: #333;
            padding: 10px;
        }
        .navbar .logo_item img {
            height: 40px;
        }
        .navbar ul {
            list-style: none;
            display: flex;
            margin: 0;
            padding: 0;
        }
        .navbar ul li {
            margin-left: 20px;
        }
        .navbar ul li a {
            color: white;
            text-decoration: none;
        }
        .navbar ul li a img {
            height: 30px;
            vertical-align: middle;
        }
        .menu-desplegable ul {
            display: none;
            position: absolute;
            background-color: white;
            border: 1px solid #ccc;
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .menu-desplegable:hover ul {
            display: block;
        }
        .menu-desplegable ul li {
            padding: 10px;
        }
        .menu-desplegable ul li a {
            color: black;
        }
    </style>
</head>
<body>
<!-- Navbar -->
<nav class="navbar">
    <div class="logo_item">
        <i class="bx bx-menu" id="sidebarOpen"></i>
        <img src="img/logo.png" alt="">EducaTec
    </div>
    <ul>
        <li class="menu-desplegable">
            <a href="#">
                <img src="img/usuarioDos.png" alt="Menú">
            </a>
            <ul class="submenu">
                <li><a href="#">Información Alumno</a></li>
                <li><a href="#">Cerrar Sesión</a></li>
            </ul>
        </li>
    </ul>
</nav>

<!-- Materias -->
<div class="container">
    <h1>Seleccionar Materia</h1>
    <?php if (!empty($message)): ?>
        <div id="message" style="background-color: #ccffcc; color: #009900; padding: 20px; border: 2px solid #009900; border-radius: 10px; text-align: center;">
            <p style="font-size: 18px; margin: 0;"><?php echo $message; ?></p>
        </div>
        <script>
            setTimeout(function() {
                var message = document.getElementById('message');
                message.style.display = 'none';
            }, 5000);
        </script>
    <?php endif; ?>
    <table>
        <tr>
            <th>Materia</th>
            <th>Maestro</th>
            <th>Día</th>
            <th>Aula</th>
            <th>Límite Inscripción</th>
            <th>Hora</th>
            <th>Acción</th>
            <th>Alumnos Inscritos</th>
        </tr>
        <?php if ($result->num_rows > 0): ?>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $row['Nombre']; ?></td>
                    <td><?php echo $row['Maestro']; ?></td>
                    <td><?php echo $row['Dia']; ?></td>
                    <td><?php echo $row['Aula']; ?></td>
                    <td><?php echo $row['Limite_Inscripcion']; ?></td>
                    <td><?php echo $row['Hora']; ?></td>
                    <td>
                        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                            <input type="hidden" name="materia_id" value="<?php echo $row['materia_id']; ?>">
                            <button type="submit">Inscribirse</button>
                        </form>
                    </td>
                    <td>
                        <?php
                        if (isset($inscripciones[$row['materia_id']])) {
                            foreach ($inscripciones[$row['materia_id']] as $inscrito) {
                                echo $inscrito . "<br>";
                            }
                        } else {
                            echo "No hay alumnos inscritos.";
                        }
                        ?>
                    </td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr>
                <td colspan="8">No se encontraron materias disponibles.</td>
            </tr>
        <?php endif; ?>
    </table>
</div>
</body>
</html>
