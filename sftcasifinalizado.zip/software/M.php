<?php
session_start();

$error_message = ""; // Inicializamos la variable de mensaje de error
// Verificar si se ha enviado el formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (empty($_POST['Nombre'])) {
        $error_message = "Completa el campo de nombre de la materia.";
    } elseif (empty($_POST['Hora'])) {
        $error_message = "Completa el campo de Hora de la clase.";
    } elseif (empty($_POST['Dia'])) {
        $error_message = "Completa el campo de Horario.";
    } elseif (empty($_POST['Aula'])) {
        $error_message = "Completa el campo de Aula.";
    } else {
        // Conexión a la base de datos
        include("conexion.php");

        // Verificar la conexión
        if ($conexion->connect_error) {
            die("Error de conexión: " . $conexion->connect_error);
        }

        // Obtener los datos del formulario
        $materia = $_POST['Nombre'];
        $horaClase = $_POST['Hora'];
        $horario = $_POST['Dia'];
        $aula = $_POST['Aula'];

        // Obtener el ID del profesor desde la variable de sesión
        $idProfesor = $_SESSION['user'];

        // Consulta SQL para insertar los datos en la tabla, asociando la materia con el profesor
        $sql = "INSERT INTO materias (Nombre, Dia, Aula, Hora, usuario_id) 
        VALUES ('$materia', '$horario', '$aula', '$horaClase', '$idProfesor')";

        if ($conexion->query($sql) === TRUE) {
            $error_message = "Materia Agregada Correctamente.";
        } else {
            $error_message = "Error al agregar Materia: " . $conexion->error;
        }

        // Cerrar la conexión
        $conexion->close();
    }

    // Mostrar el mensaje de error o éxito
    if (!empty($error_message)) {
        ?>
        <div id="error-message" style="background-color: #ffcccc; color: #cc0000; padding: 20px; border: 2px solid #cc0000; border-radius: 10px; text-align: center; position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);">
            <p style="font-size: 18px; margin: 0;"><?php echo $error_message; ?></p>
        </div>
        <script>
            setTimeout(function() {
                var errorMessage = document.getElementById('error-message');
                errorMessage.style.display = 'none';
            }, 5000); // 5000 milisegundos = 5 segundos
        </script>
        <?php
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menú Docente </title>
    <link rel="stylesheet" href="styleMenu.css">
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
</head>
<body>
<!-- navbar -->
<nav class="navbar">
    <div class="logo_item">
        <i class="bx bx-menu" id="sidebarOpen"></i>
        <img src="img/logo.png" alt="">EducaTec
    </div>
  <ul>
    <li class="menu-desplegable">
      <a href="#">
        <img src="img/usuarioDos.png" alt="Menú">
      </a>
      <ul class="submenu">
        <li><a href="#">Informacion Alumno</a></li>
        <li><a href="#">Cerrar Sesión</a></li>
      </ul>
    </li>
  </ul>
</nav>

<!-- sidebar -->
<nav class="sidebar">
    <div class="menu_content">
        <ul class="menu_items">
            <li class="item">
                <br></br>
                <a href="menudocente.php" class="nav_link submenu_item">
                <img src="img/hogar-dos.png" alt="logo" class="profile" id="profileIcon"/>
                <span class="navlink">Inicio</span>
                </a>
            </li>
            <li class="item">
                <a href="registrar_materia.php" class="nav_link submenu_item">
                <img src="img/registro.png" alt="logo" class="profile" id="profileIcon"/>
                    <span class="navlink">Registrar Materia</span>
                </a>
            </li>
            <li class="item">
                <a href="CambiarContrasena.php" class="nav_link">
                <img src="img/cambiar-contra.png" alt="logo" class="profile" id="profileIcon"/>
                    <span class="navlink">Cambiar Contraseña</span>
                </a>
            </li>
            <li class="item">
                <a href="loginDocente.php" class="nav_link">
                <img src="img/cerrar-sesion.png" alt="logo" class="profile" id="profileIcon"/>
                    <span class="navlink">Cerrar Sesión</span>
                </a>
            </li>
        </ul>
</nav>

<!-- JavaScript -->
<script src="js/script.js"></script>

<!-- Imagen de usuario -->
<style>
nav {
  position: relative;  
}

.menu-desplegable {
  position: relative; 
}

.submenu {
  display: none;  
  position: absolute;  
  top: 100%;  
  left: 0;  
  background-color: #fff;  
  padding: 10px;  
  z-index: 1; 
}

.menu-desplegable:hover .submenu {
  display: block;  
}
</style>

<!-- Bienvenida -->
<style>
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
        background-color: #9ad4fb;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
    }

    .welcome-text {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        text-align: center;
        font-size: 24px;
        font-weight: bold;
    }
</style>
<div class="welcome-text"></div>

<!-- Formulario -->
<style>
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 20px;
    }

    h1 {
        text-align: center;
        margin-bottom: 20px;
    }

    form {
        width: 500px;
        margin: 0 auto;
        padding: 20px;
        border: 1px solid #ccc;
    }

    label {
        display: block;
        margin-bottom: 5px;
    }

    input[type="text"],
    input[type="time"],
    select {
        width: 100%;
        padding: 10px;
        border: 1px solid #ccc;
        box-sizing: border-box;
    }

    button {
        background-color: #2196f3;
        color: white;
        padding: 8px 20px;
        border: none;
        cursor: pointer;
        width: 100%;
    }

    button:hover {
        background-color: #0cb7f2;
    }
</style>
<div class="container">
    <div class="form-container">
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" id="materiaForm">
            <label for="Nombre">Materia:</label>
            <select id="Nombre" name="Nombre" onchange="setDay()">
                <?php
                // Conexión a la base de datos
                include("conexion.php");

                // Verificar la conexión
                if ($conexion->connect_error) {
                    die("Error de conexión: " . $conexion->connect_error);
                }

                // Consulta SQL para obtener las materias
                $sql = "SELECT mat_id, nombre_materia, dia FROM mat_sistemas";
                $result = $conexion->query($sql);

                // Verificar si se encontraron materias
                if ($result->num_rows > 0) {
                    // Iterar sobre los resultados y generar opciones para cada materia
                    while ($row = $result->fetch_assoc()) {
                        echo "<option value=\"" . $row["nombre_materia"] . "\" data-dia=\"" . $row["dia"] . "\">" . $row["nombre_materia"] . "</option>";
                    }
                } else {
                    echo "<option value=\"\">No se encontraron materias</option>";
                }

                // Cerrar la conexión
                $conexion->close();
                ?>
            </select>
            <label for="Hora">Hora:</label>
            <select id="Hora" name="Hora">
                <option value="">Selecciona una hora</option>
                <?php
                for ($hour = 7; $hour <= 21; $hour++) {
                    $formatted_hour = ($hour < 12) ? $hour . " AM" : ($hour == 12 ? "12 PM" : ($hour - 12) . " PM");
                    $formatted_hour_value = str_pad($hour, 2, "0", STR_PAD_LEFT) . ":00";
                    echo "<option value=\"$formatted_hour_value\">$formatted_hour</option>";
                }
                ?>
            </select>
            <label for="Dia">Horario:</label>
            <select id="Dia" name="Dia" readonly>
                <option value="Lun-Vie">Lun-Vie</option>
                <option value="Lun-Jue">Lun-Jue</option>
            </select>
            <label for="Aula">Aula:</label>
            <input type="text" id="Aula" name="Aula">
            <br></br>
            <button type="submit">Agregar materia</button>
        </form>
        <script>
        function setDay() {
            var materiaSelect = document.getElementById("Nombre");
            var diaSelect = document.getElementById("Dia");

            var selectedOption = materiaSelect.options[materiaSelect.selectedIndex];
            var dia = selectedOption.getAttribute("data-dia");

            diaSelect.innerHTML = "";

            var option = document.createElement("option");
            option.text = dia;
            option.value = dia; 
            diaSelect.add(option);
        }
        document.addEventListener("DOMContentLoaded", setDay);
        </script>
    </div>
</div>
</body>
</html>
