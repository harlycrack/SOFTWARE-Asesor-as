<?php
session_start();

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['alumno_Id'])) {
    header("Location: loginAlumno.php");
    exit();
}

// Verificar si se ha enviado el ID de la materia
if (!isset($_GET['materia_id'])) {
    header("Location: mostrar_materias.php");
    exit();
}

// Conexión a la base de datos
include("conexion.php");

// Obtener el ID del alumno desde la variable de sesión
$idAlumno = $_SESSION['alumno_Id']; // Asegúrate de que este valor es el `alumno_Id`
// Obtener el ID de la materia desde la URL
$idMateria = $_GET['materia_id'];

// Verificar que el `materia_id` existe en la tabla `materias`
$sqlVerificarMateria = "SELECT * FROM materias WHERE materia_Id = '$idMateria'";
$resultMateria = $conexion->query($sqlVerificarMateria);

if ($resultMateria->num_rows == 0) {
    echo "Error: La materia no existe.";
    exit();
}

// Consulta SQL para inscribir al alumno en la materia
$sql = "INSERT INTO inscripciones (alumno_id, materia_id) VALUES ('$idAlumno', '$idMateria')";

if ($conexion->query($sql) === TRUE) {
    echo "Te has inscrito correctamente.";
} else {
    echo "Error al inscribirse: " . $conexion->error;
}

// Cerrar la conexión
$conexion->close();

header("Location: mostrar_materias.php");
exit();
?>

